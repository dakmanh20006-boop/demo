const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");
const themeBtn = document.getElementById("themeBtn");
const contactForm = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

menuBtn.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open);
});

document.querySelectorAll("#navLinks a").forEach((link) => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

// Extra 1: dark/light mode with saved preference
themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  localStorage.setItem("darkMode", dark);
  themeBtn.textContent = dark ? "☀️" : "🌙";
});

if (localStorage.getItem("darkMode") === "true") {
  document.body.classList.add("dark");
  themeBtn.textContent = "☀️";
}

// Extra 2: contact form interaction
contactForm.addEventListener("submit", (event) => {
  event.preventDefault();
  formMessage.textContent = "Thank you! Your message has been received.";
  contactForm.reset();
});

// Extra 3: automatic current year
document.getElementById("year").textContent = new Date().getFullYear();
