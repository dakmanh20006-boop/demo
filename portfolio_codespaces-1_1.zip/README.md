# Personal Portfolio

A responsive personal portfolio coded from scratch with HTML, CSS and JavaScript.

## Features
- Semantic HTML structure
- Responsive layout for desktop, tablet and mobile
- CSS Grid and Flexbox
- Dark/light mode
- Mobile navigation menu
- Contact form interaction
- Smooth scrolling
- Hover effects and skill bars

## Run in GitHub Codespaces
Open `index.html` with Live Server, then open the forwarded port in the browser.

## Before submitting
Replace:
- `Your Full Name`
- `your.email@example.com`
- Project links
- About/education information

Also test the site at desktop and mobile widths.
